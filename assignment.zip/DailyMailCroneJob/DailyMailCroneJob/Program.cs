﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace DailyMailCroneJob
{
    class Program
    {
        static void Main(string[] args)
        {
            SendMail();
        }

        public static void SendMail()
        {
            try
            {
                DataTable dataTable = new DataTable();
                string connString = @"your connection string here";
                string query = "select * from table";

                SqlConnection conn = new SqlConnection(connString);
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();

                // create data adapter
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                // this will query your database and return the result to your datatable
                da.Fill(dataTable);

                conn.Close();
                da.Dispose();

                /*1. Depending on the particular database column if its null then set it tovalue = 1 for mail sent.
                 2. once the mail is sent then on the click of the link in the mail a flag is set in the table column to value = 2.
                 3. again on the next day when the mails are being sent then check the flag value if its 2 then send a THANK YOU mail.*/

                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

                mail.From = new MailAddress("Sender mail address"); // Give sender mail address Ex. asdf@gmail.com
                mail.To.Add("mail address of the recipient");  // Give receiver mail address Ex. asdf@gmail.com
                mail.Subject = "Test Mail";
                mail.Body = "This is for testing of crone-job";

                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential("Sender mail address", "Password"); //Provide sender mail address & its password
                SmtpServer.EnableSsl = true;
                SmtpServer.Send(mail);
                Console.WriteLine("Mail sent at" + DateTime.Now);
                Console.ReadLine();
            }
            catch (Exception ex)
            {

            }
        }
    }
}
